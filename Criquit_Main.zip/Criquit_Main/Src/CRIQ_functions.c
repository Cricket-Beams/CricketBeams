#include "CRIQ_functions.h"

// Locate Global values (large arrays)
float x[512];
float y[512];
float array[268];

/* @funct:  
*	@descrip: Performs the correlation ID function for criquit noises sampled from the ADCs.
* @argin: 
* @retval: <none>
*/
void CRIQ_maxisChange(void){
	// channel config variables
	
	ADC_ChannelConfTypeDef sConfig1;
	ADC_ChannelConfTypeDef sConfig2;
	// variable to hold adc channels dependent on system state
	uint32_t ch1;
	uint32_t ch2;
	
	switch(SYS_STATE.bytes.State){
		case MAXIS_1_RDY:
				ch1 = ADC_CHANNEL_1;
				ch2 = ADC_CHANNEL_4;
			break;
		
		case MAXIS_2_RDY:
				ch1 = ADC_CHANNEL_12;
				ch2 = ADC_CHANNEL_11;
			break;
		
		case MAXIS_3_RDY:
				ch1 = ADC_CHANNEL_13;
				ch2 = ADC_CHANNEL_10;
			break;
	}
	
	// Stop the ADCs before performing a channel switch
	HAL_ADCEx_MultiModeStop_DMA(&hadc1);
	HAL_ADC_Stop(&hadc2);
    
	// Configure the ADC channels for ADC 1:
	sConfig1.Channel = ch1;
  sConfig1.Rank = 1;
  sConfig1.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig1) != HAL_OK){
    Error_Handler();
  }
  // Configure the ADC channels for ADC 2:  
	sConfig2.Channel = ch2;
  sConfig2.Rank = 1;
  sConfig2.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig2) != HAL_OK){
    Error_Handler();
  }

	// Start the ADCs
	uint8_t out = 0x0C;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
  HAL_ADC_Start(&hadc2);
	HAL_ADCEx_MultiModeStart_DMA(&hadc1,(uint32_t*) DMA_value, 512);
	out = 0x1C;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
}

/* @funct: CRIQ_locate 
*	@descrip: Performs the correlation ID function for criquit noises sampled from the ADCs.
* @argin: 
* @retval: angle of incidence, gets passed to motor function [float]
*/
float CRIQ_locate(void){
	uint8_t out = 0x0D;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
	//float x[512];
	//float y[512];
	//float array[268];
	int i = 0;
	int j = 0;
	int n = 0;
	int c = 0;
	int m;
	//variables for calculating angle
	float t, alpr, alpd; //time, angle variable
	float pi = 3.1416; //pi
	//float d = 0.0381; //distance between mics (1.5")
	float v = 340;	//speed of sound
	
	float sample = 0; // number of sample shifts for mic 1 ref
	int length = 512; //length of sample array
	int b = 269;//sort array limit
	
	//locating code:
	for(int e = 0; e < 512; e++){
		//HAL_Delay(1);
		x[e] = DMA_value[e] & 0x0000FFFF;
		//HAL_Delay(1);
		y[e] = (DMA_value[e] >> 16) & 0x0000FFFF;
		//HAL_Delay(1);
	}	

	while( j < 135 ){	
		float acc1=0;
		float acc2=0;
		float p=(x[i]/y[j]);	 //ratio of first index ADC1/ j index of ADC2
		float r=(y[i]/x[j]);		 	 

		for(m = 1 ; m < (length - j) ; m++){
			float l;
			float h;
			float q = (x[i+m] / y[j+m]);
			float u = (y[i+m] / x[j+m]);
					
			if(p >= q) 
				l = p - q;
			if(p < q) 
				l = q - p;
			if(r >=	u) 
				h = r - u; 
			if(r < u) 
				h = u - r;

			acc1 = acc1 + l;
			acc2 = acc2 + h;
		}

		float avg1 = acc1/(length-j-1);//average of the ratio deltas (1st index minus an ascending index)
		float avg2 = acc2/(length-j-1);
		
		array[n]=avg1; //average of the
		array[n+135]=avg2;

		n++;
		j++;
	}

	float minimum = array[0];
	// locate minimum difference
	for (c = 1 ; c < b ; c++){
		if(array[c] < minimum){
			minimum = array[c];
			sample = c;//location=c+1;
		}
	}
	// CALCULATE ANGLE:
	// Case for angle >90 (mic 2 ref 0-90)
	if(sample > 134){	
		float sample2 = sample - 134;
		printf("sample disparity is %f, value is %f\n", sample2, minimum);	
		t = sample2 / 1200000; // sample rate 1.2M
		alpr = asin( (t*v) / MIC_DISTANCE); //angle
		alpd = alpr*180/pi + 90;
	}
	// Case for angle <90 (mic 1 ref 0-90) 
	else{
		printf("sample disparity is %f, value is %f\n", sample, minimum);	

		t = sample/1200000; //sampling rate observed 600KHZ (PLCK2 prescaler)
		alpr = asin((t*v) / MIC_DISTANCE); //angle
		alpd = 90 - alpr*180/pi;
	}
	
	float angleNum;
	switch(SYS_STATE.bytes.State){
		case MAXIS_1_RDY:
			//TIM4->CCR1 = 1126 + 4.1556 * angle;
			angleNum = 1126 + 4.1556 * alpd;
			break;
		
		case MAXIS_2_RDY:
			//TIM4->CCR1 = 1749 + 4.1556 * angle;
			angleNum = 1749 + 4.1556 * alpd;
			break;
		
		case MAXIS_3_RDY:
			//TIM4->CCR1 = 752 + 4.1556 * angle;
			angleNum = 752 + 4.1556 * alpd;
			//break;
	}
	
	return (angleNum);
}

/* @funct: CRIQ_ID
*	@descrip: Performs the correlation ID function for criquit noises sampled from the ADCs.
* @argin: 
* @retval: 1 (for positive ID) or 0 (for negative ID), [uint8_t/bool]
*/
uint8_t CRIQ_ID( void ){

	uint8_t out = 0x0E;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
	return(1); // dummy code 
}

/* @funct: CRIQ_Attack 
*	@descrip: Performs the attack routine. Sends angle number to servo, activates PWM signal to drive speakers.
* @argin: [float] angle- 
* @retval: [uint8_t/bool] 1 (for positive ID) or 0 (for negative ID)
*/
void CRIQ_Attack( float angle ){
	uint8_t out = 0x0A;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);

	// Start the servo PWM
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
	
	// Servo pulses
#ifdef SERVO_SLOW	
	CRIQ_slowDriveServo(angle, CENTER_POSITION);
#else
	CRIQ_driveServo(angle);
	HAL_Delay(SERVO_WAIT_MS);	// delay for action to complete
#endif 
	
	out = 0x1A;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
	// Activate speaker array
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, 50);
	// Start Timer 2 with interrupt to modulate PWM
	HAL_TIM_Base_Start_IT(&htim2);
	
	// Attack for set period
	HAL_Delay(ATK_PERIOD_MS);
	
	out = 0x2A;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
	
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_3);
	HAL_TIM_Base_Stop_IT(&htim2);
	
	// Return servo to center position (180)
	// Servo pulses
#ifdef SERVO_SLOW	
		CRIQ_slowDriveServo(CENTER_POSITION, angle);
#else
	CRIQ_driveServo(CENTER_POSITION);
	HAL_Delay(SERVO_WAIT_MS);	// delay for action to complete
#endif 

	
	out = 0x3A;
	HAL_UART_Transmit(&huart2, &out, 1, 0xFFFF);
	
	// Update state tracker
	SYS_STATE.bytes.NextState = ALERT;
}

void CRIQ_slowDriveServo(float target, float prev){
	uint8_t negF = 1;
	int step = (target - 1500)/5; // 1500 = 180 degrees
	if(step < 0){
		step = step * -1;
		negF = -1;
	}
	for(uint32_t i = 0; i <= step; i++){
		TIM4->CCR1 = negF*5*i+prev;
		HAL_Delay(50);
	}
	TIM4->CCR1 = target;
	
}

void CRIQ_driveServo(float target){
	TIM4->CCR1 = target;
}